const express=require('express');
const MongoClient=require('mongodb').MongoClient
const server=express()
server.use(express.json())
var cors = require('cors');
server.use(cors());

var database
server.get('/ingredients',(req,res)=>{
    database.collection('ingredients').find({}).toArray((err,data)=>{
        if(err) throw err
        res.send(data)
        
    })
})

server.get('/pizza',(req,res)=>{
    database.collection('Pizza').find({}).toArray((err,data)=>{
        if(err) throw err
        res.send(data)
        
    })
})

server.listen(4000,()=>{
    MongoClient.connect('mongodb://127.0.0.1:27017',(err,data)=>{
        if(err){
            console.log(err)
        }
        else{
            database=data.db('Pizzaria')
            console.log('connected successfully')
        }
    })
})