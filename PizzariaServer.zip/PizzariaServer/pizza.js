const express=require('express');
const MongoClient=require('mongodb').MongoClient
const cors=require('cors')
const server=express()
server.use(express.json())
server.use(cors())
var database
server.get('/pizza',(req,res)=>{
    database.collection('Pizza').find({}).toArray((err,data)=>{
        if(err) throw err
        res.send(data)
            // console.log(err)
        
        // else{
        //     console.log(data)
        // }
    })
})
server.listen(4000,()=>{
    MongoClient.connect('mongodb://127.0.0.1:27017',{useNewUrlParser:true},(err,data)=>{
        if(err){
            console.log(err)
        }
        else{
            database=data.db('Pizzaria')
            console.log('connected successfully')
        }
    })
})