// import logo from './logo.svg';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Home from './Home';
import NavFile from './NavFile';
import OrderPizza from './OrderPizza';
import BuildPizza  from './BuildPizza';
// import Pizza from './PizzariaLogo.png';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <NavFile/>
      {/* <Route path='/' element={<NavFile/>}/> */}
      <Routes>

        <Route path='/home' element={<Home/>}
        />
        <Route path='/order' element={<OrderPizza/>}/>
        <Route path='/build' element={<BuildPizza/>}/>

      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
