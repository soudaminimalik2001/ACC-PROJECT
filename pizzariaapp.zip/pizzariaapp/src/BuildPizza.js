import { useState, useEffect } from "react";
import axios from "axios";
// import { color } from "@mui/system";


const App = () => {

  const [myData, setMyData] = useState([]);

  const [num, setNum] = useState(0);
  const changePrice = (checked,updateprice) => {
    checked ? setNum((oldprice)=>oldprice+updateprice):setNum((oldprice)=>oldprice-updateprice)
    
    
    
  };

  useEffect(() => {
    axios
      .get("http://localhost:4000/ingredients")
      .then((response) => setMyData(response.data));
  }, []);





  return (
    <>
      <div className="container">
        <table class="table table-bordered table-striped">
          <tbody>
            {myData.map((pizza) => {
              const { id, tname, price, image } = pizza;
              return (
                <tr key={id}>
                  <img src={image} width="90" height="70" alt="invalid"></img>
                  <td>{tname}</td>
                  <td>₹{price}</td>

                  <from className="style">
                    <input type="checkbox"  value="" 
                    id={pizza.id}
                    onChange={(t)=>changePrice(t.target.checked,pizza.price)}>

                    </input>
                    <label htmlFor="box">Add</label>
                  </from>
                </tr>
              );
            })}
            <h6>Total Cost:{num}</h6>
          </tbody>
          
        </table>
        <button type="button" class="btn btn-dark">
          Build Ur Pizza
        </button>
      </div>
    </>
  );
};
export default App;
