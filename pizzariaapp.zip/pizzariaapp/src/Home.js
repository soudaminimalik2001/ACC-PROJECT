import React, { Component } from 'react';
import ingredients from './ingredients1.jpg'
import Chef from './chef1.png';
import watch from './watch.jpg'
export class Home extends Component{
    render(){
        return(
            <div className='main'>
                <h2>Our Story</h2>
                <p>
                    we belive in good.We launched fresh pan pizza BestExcuse Awards on ourFacbook fan page.Fans were given situations where they had to come up
                    with wacky and fun excuses.The person with the best excuse won the Best Excuse Badge and won Pizzaria's vouchers.Their enthusiastic response proved
                    that Pizzaria's fresh pan pizza is the tastiest pan pizza.Ever!
                </p>
                <p>
                    Ever since we lanched the Tastiest Pan Pizza,ever,people have not been able to resist the softest,cheesiest,crunchiest,butteriest Domino's freshpan Pizza.
                    They have been leaving the stage in the middle of a performance and even finding excuses to be disqualifed in afootball match.
                </p>
                <p>
                    We launched fresh pan pizza best excuses awards on our facebook fan page.fans wre given situations where they had to come up with wacky and fun
                    excuses.The person with the best excuses won the best best excuse badge and won Domino's vouchers. Their enthusiastic response proved that Pizzaria's
                    fresh pan pizza is the tastiest pan pizza.Ever!
                </p>
                <nav>
                    <div className='image'>
                        <img src={ingredients} alt="invalid" height={250} width={300} float="left" ></img>
                    </div>
                    <div className='text1'>
                        <h2>Ingredients</h2>
                        <p> We're ruthless about goodness.We have no qualms about tearing up a day-old
                            lettuce leaf(straight from the farm),or steaming a baby(Carrot).Cut.Cut.Chop.
                            Chop.Steam.Steam.Stir Stir.While they're still young and fresh-that's our motto.It
                            makes the kitchen a better place.
                        </p>
                    </div>
                </nav>

                
                <div className='image1'>
                    <img src={Chef} alt='invalid'></img>
                </div>

                <div  className='chef'>

                    <h2>Our Chef</h2>
                    <p>
                        They make sauces sing and salads dance.They create magic with skill,
                        knowledge,passion,and stirring spoons(among other things).They
                        make goodness so good,it doesn't know what to do with itself.We do
                        though.We send it to you. 
                    </p>
                </div>
                <div className='image2'>
                    <img src={watch}alt="invalid"></img>45 minutes delivery
                    
                </div> 
                <div className='tag'>
                        copyright @ 2017 Pizzaria . All rights reserved.
                </div>
                

            </div>
        )
    }
}
export default Home;














