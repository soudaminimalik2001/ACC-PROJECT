import{Link} from "react-router-dom";
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import Pizza from './PizzeriaLogo.png';
// import { color } from "@mui/system";
const NavFile=()=>{
    return(
        <nav className="bg">
                <li>
                    {/* <a href="/home">Home</a><br></br> */}
                    {/* <a href="/order">OrderPizza</a><br></br> */}
                    {/* <a href="/build">BuildPizza</a><br></br> */}

                    <a className="font">Pizzaria</a>
                    <Link className='link' to={'/home'}><img src={Pizza} width={'50px'} /></Link>&nbsp;  
                                                   
                    <Link className='pizza' to={"/order"}>OrderPizza</Link>&nbsp;&nbsp; 
                    
                    <Link className='pizza' to={"/build"}>BuildPizza</Link>
 
                    <button className="cart">
                        ShoppingCart
                        <ShoppingCartIcon/>
                    </button>
               </li>
               {/* <button className="cart">
                        ShoppingCart
                        <ShoppingCartIcon/>
                </button> */}
        </nav>
    )
}
export default NavFile;