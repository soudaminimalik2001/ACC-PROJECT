import {useState,useEffect} from "react";
import axios from "axios";
const App=()=>{
    const [myData,setMyData]=useState([]);
    
    useEffect(()=>{
        axios
        .get("http://localhost:4000/pizza")
        .then((response)=>setMyData(response.data))
        
        },[]);
        return(
            <>
            
            <div className="order1">
                {myData.map((pizza)=>{
                    const {id,type,price,name,image,description,ingredients,topping}=pizza;
                    return(
                        
                        <div key={id} className="card">
                            <h2>{name}</h2>
                            <center><button style={{height:"24px",width:"20px"}} className={(type==='veg'? "btn btn-success":'btn btn-danger')} type="button">/</button></center>
                            <p>{type}</p>
                            <p>₹{price}</p>
                
                            <img src={image }width="200px" height="200px" align="right" alt="invalid"></img>
                            <button className="butt" type="button" class="btn btn-outline-warning btn-sm" value="Warning">Add to Cart</button>
                            <p>{description}</p>
                            <p><h6>Ingredients:</h6>{ingredients}</p>
                            <p><h6>Topping:</h6>{topping}</p>
                            

                        </div>
                    );
                })}
            </div>
            </>
        );
}
export default App;